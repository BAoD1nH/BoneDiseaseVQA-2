from label2idx import build_label_mappings

__all__ = [ build_label_mappings ]